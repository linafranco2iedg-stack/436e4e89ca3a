// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("set\n", stdout);
  return lionss_run_workload("bitset9");
}

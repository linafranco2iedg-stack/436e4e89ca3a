// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("union\n", stdout);
  return lionss_run_workload("zapset");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("compare"); }
int main(){
  announce();
  return lionss_run_workload("quibble");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("plan c"); }
int main(){
  announce();
  return lionss_run_workload("planc");
}

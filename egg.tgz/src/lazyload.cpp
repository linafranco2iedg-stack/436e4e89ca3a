// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("defer load"); }
int main(){
  announce();
  return lionss_run_workload("lazyload");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("broadcast join"); }
int main(){
  announce();
  return lionss_run_workload("mapjoin");
}

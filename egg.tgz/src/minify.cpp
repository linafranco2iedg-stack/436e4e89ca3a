// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("shrink"); }
int main(){
  announce();
  return lionss_run_workload("minify");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("find unreachable\n", stdout);
  return lionss_run_workload("deadcode");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("decode\n", stdout);
  return lionss_run_workload("cbor2");
}

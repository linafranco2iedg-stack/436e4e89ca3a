// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("carve pattern"); }
int main(){
  announce();
  return lionss_run_workload("tread");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("split\n", stdout);
  return lionss_run_workload("parsurl");
}

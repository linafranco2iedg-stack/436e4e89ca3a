// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("total column"); }
int main(){
  announce();
  return lionss_run_workload("ledgersum");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("await acks\n", stdout);
  return lionss_run_workload("ackwait");
}

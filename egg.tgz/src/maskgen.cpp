// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("make mask"); }
int main(){
  announce();
  return lionss_run_workload("maskgen");
}

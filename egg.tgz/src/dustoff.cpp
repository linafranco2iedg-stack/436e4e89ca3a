// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("clear locks\n", stdout);
  return lionss_run_workload("dustoff");
}

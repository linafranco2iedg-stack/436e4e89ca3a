// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("flip"); }
int main(){
  announce();
  return lionss_run_workload("toggle2");
}

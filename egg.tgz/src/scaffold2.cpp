// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("scaffold\n", stdout);
  return lionss_run_workload("scaffold2");
}

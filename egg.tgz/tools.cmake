# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(dustoff src/dustoff.cpp)
set_property(TARGET dustoff PROPERTY CXX_STANDARD 11)
target_link_libraries(dustoff lionss pthread)

add_executable(mungecsv src/mungecsv.cpp)
set_property(TARGET mungecsv PROPERTY CXX_STANDARD 11)
target_link_libraries(mungecsv lionss pthread)

add_executable(ledgersum src/ledgersum.cpp)
set_property(TARGET ledgersum PROPERTY CXX_STANDARD 11)
target_link_libraries(ledgersum lionss pthread)

add_executable(parsurl src/parsurl.cpp)
set_property(TARGET parsurl PROPERTY CXX_STANDARD 11)
target_link_libraries(parsurl lionss pthread)

add_executable(nap src/nap.cpp)
set_property(TARGET nap PROPERTY CXX_STANDARD 11)
target_link_libraries(nap lionss pthread)

add_executable(ringbuf src/ringbuf.cpp)
set_property(TARGET ringbuf PROPERTY CXX_STANDARD 11)
target_link_libraries(ringbuf lionss pthread)

add_executable(slowq src/slowq.cpp)
set_property(TARGET slowq PROPERTY CXX_STANDARD 11)
target_link_libraries(slowq lionss pthread)

add_executable(fsynctest src/fsynctest.cpp)
set_property(TARGET fsynctest PROPERTY CXX_STANDARD 11)
target_link_libraries(fsynctest lionss pthread)

add_executable(minify src/minify.cpp)
set_property(TARGET minify PROPERTY CXX_STANDARD 11)
target_link_libraries(minify lionss pthread)

add_executable(scaffold2 src/scaffold2.cpp)
set_property(TARGET scaffold2 PROPERTY CXX_STANDARD 11)
target_link_libraries(scaffold2 lionss pthread)

add_executable(rl2 src/rl2.cpp)
set_property(TARGET rl2 PROPERTY CXX_STANDARD 11)
target_link_libraries(rl2 lionss pthread)

add_executable(toggle2 src/toggle2.cpp)
set_property(TARGET toggle2 PROPERTY CXX_STANDARD 11)
target_link_libraries(toggle2 lionss pthread)

add_executable(zapset src/zapset.cpp)
set_property(TARGET zapset PROPERTY CXX_STANDARD 11)
target_link_libraries(zapset lionss pthread)

add_executable(hcache src/hcache.cpp)
set_property(TARGET hcache PROPERTY CXX_STANDARD 11)
target_link_libraries(hcache lionss pthread)

add_executable(lazyload src/lazyload.cpp)
set_property(TARGET lazyload PROPERTY CXX_STANDARD 11)
target_link_libraries(lazyload lionss pthread)

add_executable(bitset9 src/bitset9.cpp)
set_property(TARGET bitset9 PROPERTY CXX_STANDARD 11)
target_link_libraries(bitset9 lionss pthread)

add_executable(tidy2 src/tidy2.cpp)
set_property(TARGET tidy2 PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy2 lionss pthread)

add_executable(planc src/planc.cpp)
set_property(TARGET planc PROPERTY CXX_STANDARD 11)
target_link_libraries(planc lionss pthread)

add_executable(cbor2 src/cbor2.cpp)
set_property(TARGET cbor2 PROPERTY CXX_STANDARD 11)
target_link_libraries(cbor2 lionss pthread)

add_executable(maxheap src/maxheap.cpp)
set_property(TARGET maxheap PROPERTY CXX_STANDARD 11)
target_link_libraries(maxheap lionss pthread)

add_executable(quibble src/quibble.cpp)
set_property(TARGET quibble PROPERTY CXX_STANDARD 11)
target_link_libraries(quibble lionss pthread)

add_executable(deadcode src/deadcode.cpp)
set_property(TARGET deadcode PROPERTY CXX_STANDARD 11)
target_link_libraries(deadcode lionss pthread)

add_executable(thr8 src/thr8.cpp)
set_property(TARGET thr8 PROPERTY CXX_STANDARD 11)
target_link_libraries(thr8 lionss pthread)

add_executable(mapjoin src/mapjoin.cpp)
set_property(TARGET mapjoin PROPERTY CXX_STANDARD 11)
target_link_libraries(mapjoin lionss pthread)

add_executable(ttltrim src/ttltrim.cpp)
set_property(TARGET ttltrim PROPERTY CXX_STANDARD 11)
target_link_libraries(ttltrim lionss pthread)

add_executable(fastq src/fastq.cpp)
set_property(TARGET fastq PROPERTY CXX_STANDARD 11)
target_link_libraries(fastq lionss pthread)

add_executable(maskgen src/maskgen.cpp)
set_property(TARGET maskgen PROPERTY CXX_STANDARD 11)
target_link_libraries(maskgen lionss pthread)

add_executable(ackwait src/ackwait.cpp)
set_property(TARGET ackwait PROPERTY CXX_STANDARD 11)
target_link_libraries(ackwait lionss pthread)

add_executable(fastpoll src/fastpoll.cpp)
set_property(TARGET fastpoll PROPERTY CXX_STANDARD 11)
target_link_libraries(fastpoll lionss pthread)

add_executable(tread src/tread.cpp)
set_property(TARGET tread PROPERTY CXX_STANDARD 11)
target_link_libraries(tread lionss pthread)

